/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo.DAO_productos;
import modelo.DAO_usuario;
import modelo.productos;
import modelo.usuarios;

/**
 *
 * @author DUVER NAVEROS
 */
public class BuscarProducto extends HttpServlet {

    productos product = new productos();
    usuarios usu = new usuarios();
    DAO_productos daoproductos = new DAO_productos();
    DAO_usuario daousuario = new DAO_usuario();
    List<productos> productoCarro = new ArrayList<>();
    int cant = 0;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        String menu = request.getParameter("menu");
        if (menu.equalsIgnoreCase("admin")) {
            switch (accion) {
                case "buscarProducto":
                    try {
                    int id = parseInt(request.getParameter("busqueda"));
                    List lista4 = daoproductos.listarId(id);
                    request.setAttribute("index-administador", lista4);
                    request.getRequestDispatcher("index-admistrador.jsp").forward(request, response);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "error al buscar el producto");
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
                break;
                case "carro":
                    try {
                    int id = parseInt(request.getParameter("id"));
                    List lista = daoproductos.listarId(id);
                    productoCarro.add((productos) lista.get(0));
                    request.getRequestDispatcher("controlador?menu=principal&accion=listar").forward(request, response);
                } catch (Exception e) {
                    request.getRequestDispatcher("controlador?menu=principal&accion=listar").forward(request, response);
                }
                break;
                case "carroCompras":
                    try {
                    request.setAttribute("listaProduct", productoCarro);
                    request.getRequestDispatcher("carritoCompras.jsp").forward(request, response);
                } catch (Exception e) {
                    request.getRequestDispatcher("controlador?menu=principal&accion=listar").forward(request, response);
                }
                break;
                case "carroH":
                    try {
                    int id = parseInt(request.getParameter("id"));
                    List lista = daoproductos.listarId(id);
                    productoCarro.add((productos) lista.get(0));
                    request.getRequestDispatcher("controlador?menu=categoria_hombres&accion=listar").forward(request, response);
                } catch (Exception e) {
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
                break;
                case "carroM":
                    try {
                    int id = parseInt(request.getParameter("id"));
                    List lista = daoproductos.listarId(id);
                    productoCarro.add((productos) lista.get(0));
                    request.getRequestDispatcher("controlador?menu=categoria_mujer&accion=listar").forward(request, response);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "error al agregar el producto");
                    request.getRequestDispatcher("controlador?menu=categoria_mujer&accion=listar").forward(request, response);
                }
                break;
                case "carroN":
                    try {
                    int id = parseInt(request.getParameter("id"));
                    List lista = daoproductos.listarId(id);
                    productoCarro.add((productos) lista.get(0));
                    request.getRequestDispatcher("controlador?menu=principal&accion=listar").forward(request, response);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "error al agregar el producto");
                    request.getRequestDispatcher("controlador?menu=principal&accion=listar").forward(request, response);
                }
                break;
                case "eliminarElemento":
                    try {
                    int id = parseInt(request.getParameter("id"));
                    List lista = daoproductos.listarId(id);
                    product = (productos) lista.get(0);
                    for (int i = 0; i < productoCarro.size(); i++) {
                        if (productoCarro.get(i).getId() == product.getId()) {
                            productoCarro.remove(i);
                        }
                    }
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=listarCarro").forward(request, response);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "error al eliminar el producto");
                }
                break;
                case "listarCarro":
                    try {
                    request.setAttribute("listaProduct", productoCarro);
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=carroCompras").forward(request, response);
                } catch (Exception e) {
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
                break;
                case "eliminarFactura":
                    try {
                    productoCarro.clear();
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=carroCompras").forward(request, response);
                } catch (Exception e) {
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=carroCompras").forward(request, response);
                }
                break;
                case "generarFactura":
                    try {
                    Document documento = new Document();
                    int numero = 0;
                    Random rango = new Random();
                    numero = rango.nextInt(1000000001);
                    FileOutputStream fos = new FileOutputStream("C:\\Users\\DUVERNEY\\Documents\\trabajo segundo semestre\\poo\\DSC_STORE\\web\\facturas\\facturagenerada" + numero + ".pdf");
                    PdfWriter pdfW = PdfWriter.getInstance(documento, fos);
                    pdfW.setInitialLeading(20);
                    documento.open();
                    try {
                        Image foto = Image.getInstance("C:\\Users\\DUVERNEY\\Documents\\trabajo segundo semestre\\poo\\DSC_STORE\\web\\assets\\img\\icono.png");
                        foto.scaleToFit(100, 100);
                        foto.setAlignment(Chunk.ALIGN_MIDDLE);
                        documento.add(foto);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Paragraph p = new Paragraph("FACTURA");
                    p.setAlignment(Element.ALIGN_CENTER);
                    documento.add(p);
                    documento.add(Chunk.NEWLINE);
                    PdfPTable tabla = new PdfPTable(3);
                    tabla.addCell("ID");
                    tabla.addCell("NOMBRE");
                    tabla.addCell("PRECIO");
                    int j = 0;
                    double total = 0, precioP;
                    String id = "", totalP = "", precio="";
                    for (int i = 0; i < productoCarro.size(); i++) {
                        j = productoCarro.get(i).getId();
                        id = String.valueOf(j);
                        tabla.addCell(id);
                        tabla.addCell(productoCarro.get(i).getNombre());
                        j = (int)productoCarro.get(i).getPrecio();
                        total += j;
                        precio = Double.toString(productoCarro.get(i).getPrecio());
                        tabla.addCell(precio);
                    }
                    tabla.addCell("");
                    tabla.addCell("TOTAL");
                    totalP = String.valueOf(total);
                    tabla.addCell(totalP);
                    documento.add(tabla);
                    documento.close();

                    JOptionPane.showMessageDialog(null, "FACTURA GENERADA EXITOSAMENTE");
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=carroCompras").forward(request, response);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "error al generar la factura "+e.getMessage());
                    request.getRequestDispatcher("BuscarProducto?menu=admin&accion=carroCompras").forward(request, response);
                }
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
